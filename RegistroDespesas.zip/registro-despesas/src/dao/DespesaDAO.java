package dao;

import model.Despesa;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class DespesaDAO {

    // Método para adicionar uma nova despesa ao banco
    public void adicionarDespesa(Despesa despesa) {
        String sql = "INSERT INTO despesas (usuario_id, descricao, valor, categoria, data, forma_pagamento) VALUES (?, ?, ?, ?, ?, ?)";

        try (Connection conn = Conexao.conectar();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, despesa.getUsuarioId());
            stmt.setString(2, despesa.getDescricao());
            stmt.setDouble(3, despesa.getValor());
            stmt.setString(4, despesa.getCategoria());
            stmt.setDate(5, new java.sql.Date(despesa.getData().getTime()));
            stmt.setString(6, despesa.getFormaPagamento());

            stmt.executeUpdate();
            System.out.println("✅ Despesa adicionada com sucesso!");

        } catch (SQLException e) {
            System.out.println("❌ Erro ao adicionar despesa: " + e.getMessage());
        }
    }

    // Método para atualizar uma despesa existente
    public void atualizarDespesa(Despesa despesa) {
        String sql = "UPDATE despesas SET descricao = ?, valor = ?, categoria = ?, data = ?, forma_pagamento = ? WHERE id = ?";

        try (Connection conn = Conexao.conectar();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, despesa.getDescricao());
            stmt.setDouble(2, despesa.getValor());
            stmt.setString(3, despesa.getCategoria());
            stmt.setDate(4, new java.sql.Date(despesa.getData().getTime()));
            stmt.setString(5, despesa.getFormaPagamento());
            stmt.setInt(6, despesa.getId());

            stmt.executeUpdate();
            System.out.println("✅ Despesa atualizada com sucesso!");

        } catch (SQLException e) {
            System.out.println("❌ Erro ao atualizar despesa: " + e.getMessage());
        }
    }

    // Método para excluir uma despesa
    public void excluirDespesa(int id) {
        String sql = "DELETE FROM despesas WHERE id = ?";

        try (Connection conn = Conexao.conectar();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, id);
            stmt.executeUpdate();
            System.out.println("✅ Despesa excluída com sucesso!");

        } catch (SQLException e) {
            System.out.println("❌ Erro ao excluir despesa: " + e.getMessage());
        }
    }

    // Método para buscar todas as despesas de um usuário
    public List<Despesa> listarDespesas(int usuarioId) {
        List<Despesa> lista = new ArrayList<>();
        String sql = "SELECT * FROM despesas WHERE usuario_id = ? ORDER BY data DESC";

        try (Connection conn = Conexao.conectar();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, usuarioId);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                Despesa despesa = new Despesa();
                despesa.setId(rs.getInt("id"));
                despesa.setUsuarioId(rs.getInt("usuario_id"));
                despesa.setDescricao(rs.getString("descricao"));
                despesa.setValor(rs.getDouble("valor"));
                despesa.setCategoria(rs.getString("categoria"));
                despesa.setData(rs.getDate("data"));
                despesa.setFormaPagamento(rs.getString("forma_pagamento"));

                lista.add(despesa);
            }

        } catch (SQLException e) {
            System.out.println("❌ Erro ao listar despesas: " + e.getMessage());
        }

        return lista;
    }

    // Método para buscar uma despesa pelo ID
    public Despesa buscarDespesaPorId(int id) {
        String sql = "SELECT * FROM despesas WHERE id = ?";
        Despesa despesa = null;

        try (Connection conn = Conexao.conectar();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                despesa = new Despesa();
                despesa.setId(rs.getInt("id"));
                despesa.setUsuarioId(rs.getInt("usuario_id"));
                despesa.setDescricao(rs.getString("descricao"));
                despesa.setValor(rs.getDouble("valor"));
                despesa.setCategoria(rs.getString("categoria"));
                despesa.setData(rs.getDate("data"));
                despesa.setFormaPagamento(rs.getString("forma_pagamento"));
            }

        } catch (SQLException e) {
            System.out.println("❌ Erro ao buscar despesa: " + e.getMessage());
        }

        return despesa;
    }
}