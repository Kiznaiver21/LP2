package main;

import dao.DespesaDAO;
import model.Despesa;

import java.util.Date;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        DespesaDAO despesaDAO = new DespesaDAO();

        // Criar uma nova despesa
        Despesa novaDespesa = new Despesa(0, 1, "Luz", 100.00, "Contas", new Date(), "Crédito");
        despesaDAO.adicionarDespesa(novaDespesa);

        // Listar todas as despesas do usuário 1
        List<Despesa> despesas = despesaDAO.listarDespesas(1);
        for (Despesa d : despesas) {
            System.out.println("💰 Despesa: " + d.getDescricao() + " - R$ " + d.getValor());
        }

        // Atualizar uma despesa (exemplo: ID 1)
        //Despesa despesaExistente = despesaDAO.buscarDespesaPorId(1);
        //if (despesaExistente != null) {
        //    despesaExistente.setValor(120.00); // Alterando valor
        //    despesaDAO.atualizarDespesa(despesaExistente);
        //}

        // Excluir uma despesa (exemplo: ID 2)
       //despesaDAO.excluirDespesa(12);
    }
}
