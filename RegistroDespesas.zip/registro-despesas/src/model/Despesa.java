package model;

import java.util.Date;

public class Despesa {
    private int id;
    private int usuarioId;
    private String descricao;
    private double valor;
    private String categoria;
    private Date data;
    private String formaPagamento;

    public Despesa() {}

    public Despesa(int id, int usuarioId, String descricao, double valor, String categoria, Date data, String formaPagamento) {
        this.id = id;
        this.usuarioId = usuarioId;
        this.descricao = descricao;
        this.valor = valor;
        this.categoria = categoria;
        this.data = data;
        this.formaPagamento = formaPagamento;
    }

    // Getters e Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public int getUsuarioId() { return usuarioId; }
    public void setUsuarioId(int usuarioId) { this.usuarioId = usuarioId; }

    public String getDescricao() { return descricao; }
    public void setDescricao(String descricao) { this.descricao = descricao; }

    public double getValor() { return valor; }
    public void setValor(double valor) { this.valor = valor; }

    public String getCategoria() { return categoria; }
    public void setCategoria(String categoria) { this.categoria = categoria; }

    public Date getData() { return data; }
    public void setData(Date data) { this.data = data; }

    public String getFormaPagamento() { return formaPagamento; }
    public void setFormaPagamento(String formaPagamento) { this.formaPagamento = formaPagamento; }
}

