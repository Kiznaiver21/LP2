package view;

import dao.DespesaDAO;
import model.Despesa;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Date;
import java.util.List;

public class TelaDespesas extends JFrame {
    private JTextField txtDescricao, txtValor, txtCategoria, txtFormaPagamento;
    private JTable tabelaDespesas;
    private DefaultTableModel modeloTabela;
    private JButton btnAdicionar, btnEditar, btnExcluir;
    private int usuarioId = 1; // Simulando um usuário logado (mudar para pegar do login)

    public TelaDespesas() {
        setTitle("Gerenciador de Despesas");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        // Painel Superior - Formulário de Cadastro
        JPanel painelSuperior = new JPanel(new GridLayout(2, 4, 5, 5));
        painelSuperior.setBorder(BorderFactory.createTitledBorder("Nova Despesa"));

        txtDescricao = new JTextField();
        txtValor = new JTextField();
        txtCategoria = new JTextField();
        txtFormaPagamento = new JTextField();

        painelSuperior.add(new JLabel("Descrição:"));
        painelSuperior.add(txtDescricao);
        painelSuperior.add(new JLabel("Valor (R$):"));
        painelSuperior.add(txtValor);
        painelSuperior.add(new JLabel("Categoria:"));
        painelSuperior.add(txtCategoria);
        painelSuperior.add(new JLabel("Forma de Pagamento:"));
        painelSuperior.add(txtFormaPagamento);

        add(painelSuperior, BorderLayout.NORTH);

        // Tabela para exibir despesas
        modeloTabela = new DefaultTableModel(new Object[]{"ID", "Descrição", "Valor", "Categoria", "Data", "Pagamento"}, 0);
        tabelaDespesas = new JTable(modeloTabela);
        add(new JScrollPane(tabelaDespesas), BorderLayout.CENTER);

        // Painel Inferior - Botões
        JPanel painelBotoes = new JPanel();

        btnAdicionar = new JButton("Adicionar");
        btnEditar = new JButton("Editar");
        btnExcluir = new JButton("Excluir");

        painelBotoes.add(btnAdicionar);
        painelBotoes.add(btnEditar);
        painelBotoes.add(btnExcluir);

        add(painelBotoes, BorderLayout.SOUTH);

        // Ações dos Botões
        carregarDespesas();
        configurarEventos();
    }

    // Método para carregar as despesas do banco e exibir na tabela
    private void carregarDespesas() {
        modeloTabela.setRowCount(0); // Limpa a tabela
        DespesaDAO dao = new DespesaDAO();
        List<Despesa> despesas = dao.listarDespesas(usuarioId);

        for (Despesa d : despesas) {
            modeloTabela.addRow(new Object[]{d.getId(), d.getDescricao(), d.getValor(), d.getCategoria(), d.getData(), d.getFormaPagamento()});
        }
    }

    // Configuração dos eventos dos botões
    private void configurarEventos() {
        btnAdicionar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                adicionarDespesa();
            }
        });

        btnEditar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                editarDespesa();
            }
        });

        btnExcluir.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                excluirDespesa();
            }
        });
    }

    // Adiciona uma nova despesa
    private void adicionarDespesa() {
        String descricao = txtDescricao.getText();
        double valor = Double.parseDouble(txtValor.getText());
        String categoria = txtCategoria.getText();
        String formaPagamento = txtFormaPagamento.getText();

        Despesa despesa = new Despesa(0, usuarioId, descricao, valor, categoria, new Date(), formaPagamento);
        DespesaDAO dao = new DespesaDAO();
        dao.adicionarDespesa(despesa);

        carregarDespesas();
        limparCampos();
    }

    // Edita uma despesa existente
    private void editarDespesa() {
        int linhaSelecionada = tabelaDespesas.getSelectedRow();
        if (linhaSelecionada == -1) {
            JOptionPane.showMessageDialog(this, "Selecione uma despesa para editar.");
            return;
        }

        int id = (int) modeloTabela.getValueAt(linhaSelecionada, 0);
        String descricao = JOptionPane.showInputDialog("Nova descrição:", modeloTabela.getValueAt(linhaSelecionada, 1));
        double valor = Double.parseDouble(JOptionPane.showInputDialog("Novo valor:", modeloTabela.getValueAt(linhaSelecionada, 2)));
        String categoria = JOptionPane.showInputDialog("Nova categoria:", modeloTabela.getValueAt(linhaSelecionada, 3));
        String formaPagamento = JOptionPane.showInputDialog("Nova forma de pagamento:", modeloTabela.getValueAt(linhaSelecionada, 5));

        Despesa despesa = new Despesa(id, usuarioId, descricao, valor, categoria, new Date(), formaPagamento);
        DespesaDAO dao = new DespesaDAO();
        dao.atualizarDespesa(despesa);

        carregarDespesas();
    }

    // Exclui uma despesa
    private void excluirDespesa() {
        int linhaSelecionada = tabelaDespesas.getSelectedRow();
        if (linhaSelecionada == -1) {
            JOptionPane.showMessageDialog(this, "Selecione uma despesa para excluir.");
            return;
        }

        int id = (int) modeloTabela.getValueAt(linhaSelecionada, 0);
        int confirmacao = JOptionPane.showConfirmDialog(this, "Tem certeza que deseja excluir?", "Confirmação", JOptionPane.YES_NO_OPTION);

        if (confirmacao == JOptionPane.YES_OPTION) {
            DespesaDAO dao = new DespesaDAO();
            dao.excluirDespesa(id);

            carregarDespesas();
        }
    }

    // Limpa os campos após adicionar uma despesa
    private void limparCampos() {
        txtDescricao.setText("");
        txtValor.setText("");
        txtCategoria.setText("");
        txtFormaPagamento.setText("");
    }

    // Método principal para rodar a tela
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new TelaDespesas().setVisible(true));
    }
}